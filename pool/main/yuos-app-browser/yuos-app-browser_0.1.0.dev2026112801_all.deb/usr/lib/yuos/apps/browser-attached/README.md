# `yu app browser-attached`

Operate the user's running Helium tabs while preserving their cookies, SSO,
MFA, extensions, and visible browser state.

```text
CLI or Agent
  -> authenticated App Gateway
  -> MCP-only browser-attached App
  -> private stdin runtime bridge
  -> typed system.browser.control route
  -> yuosd exact-capability check
  -> root-only Native Messaging socket
  -> Chromium extension and top-frame content script
  -> user's tab
```

The App sandbox never receives the browser socket. `yuosd` maps the closed
request schema to a fixed extension verb and injects `expected_origin`,
`allow_secret`, and `allow_eval` only after authorization. The extension and
content script verify the full `scheme://host:effective-port` origin
immediately before acting.

## Tools

| Tool | Required capability | Scope |
| --- | --- | --- |
| `tabs.list` | `browser.tabs.read` | wild |
| `tabs.activate` | `browser.tabs.read` | wild |
| `nav.go` | `browser.nav` + `memory.write` | URL host + App self-ref |
| `nav.follow` | `browser.nav` | `page_url` host |
| `dom.query` | `browser.dom.read` | `page_url` host |
| `dom.click` | `browser.dom.write` | `page_url` host |
| `dom.fill` | `browser.dom.write` | `page_url` host |
| `dom.fill_secret` | `browser.input.secret` | `page_url` host |
| `page.snapshot` | `browser.dom.read` | `page_url` host |
| `page.screenshot` | `browser.dom.read` + `fs.write` | `page_url` host + new output path |
| `eval` | `browser.eval` | `page_url` host |

Use the URL returned by `tabs.list` as `--page-url` for tab-content tools.
`dom.fill_secret` and `eval` remain admin-only and approval-gated.

Use `page.snapshot` with `kind: "links"` to get visible same-origin link
labels and one-use references from the active tab. `nav.follow` rechecks the
source document and link before navigating; `verified: false` means inspect
the current tab instead of repeating the request. An updated OS browser
bridge is needed for these two opt-in paths; existing browsing is unchanged.

## Files

| Path | Role |
| --- | --- |
| `app.json` | Authoritative MCP tool, argument, and capability contract |
| `main.py` | Typed business operations and local policy checks |
| `server.py` | Direct `yuos_sdk.mcp` handlers |
| `native_host.py` | Root-client-only Unix socket to Chromium Native Messaging bridge |

See [`yuos/docs/browser-attached-design.md`](https://github.com/xiaoyu-work/Yu-OS/blob/main/docs/browser-attached-design.md)
for the full trust and data-flow design.
